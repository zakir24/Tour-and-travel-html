<html>
<head>
<center><h1><font color="white">Tour And Travel management system</font></h1></center>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<div class="topnav">
  <a class="active" href="galary.php">Home</a>
  <a href="login.php">Login</a>
<a href="register.php">Signup</a>
<a href="promotional.php">Promotional meassge</a>
  <a href="contact.php">Contact</a>
  <a href="about.php">About us</a>

</div>

<div style="padding-left:16px">
  
</div>

</body>
</html>


<body bgcolor='burlywood'>

<style>
div.gallery {
  margin: 17px;
  border: 3px solid #ccc;
  float: left;
  width: 330px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 25px;
  text-align: center;
}
</style>
</head>
<body>

<div class="gallery">
  <a target="_blank" href="tour1des.php">
    <img src="tour1i.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Sundarban tour package cruise for 3 days 2 nights. </div>
</div>

<div class="gallery">
  <a target="_blank" href="tour2des.php">
    <img src="tour2i.jpg" alt="Forest" width="600" height="400">
  </a>
  <div class="desc">Dhaka - Rangamati - Bandarban - Dhaka 4 Nights / 3 Days</div>
</div>

<div class="gallery">
  <a target="_blank" href="tour3des.php">
    <img src="tour3i.jpg" alt="Northern Lights" width="600" height="400">
  </a>
  <div class="desc">WEEKEND TOUR PACKAGE TO SREEMANGAL</div>
</div>

<div class="gallery">
  <a target="_blank" href="tour4des.php">
    <img src="tour4i.jpg" alt="Mountains" width="600" height="400">

  </a>
  <div class="desc">Bandarban Tour package 3 Nights 2 Days </div>
</div>

<div class="gallery">
  <a target="_blank" href="tour5des.php">
    <img src="tour5i.jpg" alt="Mountains" width="600" height="400">

  </a>
  <div class="desc">Cox's Bazar
04 Days & 03 Nights</div>
</div>



 
<div class="gallery">
  <a target="_blank" href="tour6des.php">
    <img src="tour6i.jpg" alt="Mountains" width="600" height="400">

  </a>
  <div class="desc">Sajek Valley and Khagrachari 2 Days 1 Night Standard Package</div>
</div>

<div class="gallery">
  <a target="_blank" href="tour7des.php">
    <img src="tour7i.jpg" alt="Mountains" width="600" height="400">

  </a>
  <div class="desc">sajek bazar Tour 3 Nights 2 Days</div>
</div>

<div class="gallery">
  <a target="_blank" href="tour8des.php">
    <img src="tour8i.jpg" alt="Mountains" width="600" height="400">

  </a>
  <div class="desc">Saint Martin Tour Package 4 Nights 3 Days</div>
</div>



</body>
</html>

<!DOCTYPE html>

<html>
<head>
<center><h1><font color="white">Tour And Travel management system</font></h1></center>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;       
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>
</head>


<div class="topnav">
  <a class="active" href="galary.php">Home</a>
  <a href="login.php">Login</a>
<a href="register.php">Signup</a>
<a href="promotional.php">Promotional meassge</a>
  <a href="contact.php">Contact</a>
  <a href="about.php">About us</a>

</div>
 
  
 
  

<div style="padding-left:16px">


<body bgcolor='burlywood'>

<style>
img {
  float: left;
}
</style>

<body>



<p><img src="tour5i.jpg" alt="Pineapple" style="width:670px;height:370px;margin-left:5px;margin-right:15px;">

 
<b>
 <font color = "green">Price:</font>	<font color = "red">8,000<br><br></font>
 <font color = "green">ID:</font>	<font color = "red">15540 <br><br></font>
 <font color = "green">Item:	</font><font color = "red">Tour Package<br><br></font>
 <font color = "green">Status:	</font><font color = "red">Available<br><br></font>
 <font color = "green">Updated:</font><font color = "red">1 months ago</font>
</b>
</p>
<head>
      <title>Title of the document</title>
      <style>
         .button {
         background-color: green;
         border: none;
         color: white;
         padding: 20px 34px;
         text-align: center;
         text-decoration: none;
         display: inline-block;
         font-size: 20px;
         margin: 4px 2px;
         cursor: pointer;
         }
      </style>
   </head>
   <body>
      <a href="logindes.php" class="button">Book now</a>
   </body>


<h4>The City of British captain Hiram Cox. Having the world�s longest unbroken sandy sea beach (120 km) sloping gently down to the blue water of the Bay of Bengal.
In Cox�s Bazar have many colorful Pagodas, Buddhist Temples, Dry fish center etc. The beauty of sun setting on the rolling sea wave and moonlit night is simply captivating. All together give the aura of the fairyland a Tourist Paradise. Interesting place around Cox�s Bazar Himchari, Ramu, Sonadia Island, Moheshkalil Island, Teknef, and St. Martin Island</h4>

<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<table id="customers">
  
  <tr>
    <td>Duration</td>
    <td>3 Days, 4 Nights</td>
   
  </tr>
  <tr>
    <td>Departure</td>
    <td>Dhaka</td>
    
  </tr>
  <tr>
    <td>Destination</td>
    <td> Cox's bazar</td>
    
  </tr>
  <tr>
    <td>Transport</td>
    <td>Coach  Bus</td>
  
  </tr>
  <tr>
    <td>Accommodation</td>
    <td>Standard hotels</td>
    
  </tr>
  <tr>
    <td>Breakfast</td>
    <td>1. Toast, Butter, Egg-Omlet / Fry, Jam, Sundaban's Honey, Seasonal Fruit, Tea and Coffee 2. Chapati, Omlet, Mixed Vegetable, Sundarban's Honey, Fresh Fruit, Tea and Coffee</td>
    
  </tr>
  <tr>
    <td>Lunch</td>
    <td>1. Plain Rice, Mixed Vegetable, Thick Dal, Fish Fry, Salad, Dessert, Tea and Coffee 2. Plain Polau, Fried Vegetable, Chicken Curry, Salad, Dessert, Tea and Coffee 3. Khichuri, Potato Chop, Fried Vegetable, Mutton Curry, Salad, Dessert, Tea and Coffee</td>
    
  </tr>
  <tr>
    <td>Dinner</td>
    <td>1. Plain Rice, Vegetable Chop, Thick Dal, Fish or Chicken Curry, Mixed Vegetable, Salad, Dessert, Tea & Coffee 2. Fried Rice, Boiled Vegetable, Chicken Curry, Salad, Dessert, Tea & Coffee 3. Fried Rice, Mixed Vegetable, Fish Curry, Salad, Tea & Coffee, Dessert / Plain Rice, Mixed Vegetable, Chicken Curry, Fish Curry, Thick Dal, Cold Drinks or Chicken Fried Rice, Chicken Fry, French Fry, Vegetables</td>
   
  </tr>
  <tr>
    <td>Sight Seeing</td>
    <td>Yes</td>
   
  </tr>
  <tr>
    <td>Guide Service</td>
    <td>Yes</td>
    
  </tr>
<tr>
    <td>Day1 Plan</td>
    <td>Leave Dhaka for cox's bazar by reserved car/coach - Overnight journey.</td>
    
  </tr>

<tr>
    <td>Day2 Plan</td>
    <td>Arrive early in the morning & transfer to hotel  � Arrive early in the morning & transfer to hotel
Take Breakfast at hotel (own cost)
Start visit to Himchory & coral beach Innani by open Jeep
Overnight stay at hotel.</td>
    
  </tr>
<tr>
    <td>Day3 Plan</td>
    <td>Breakfast at hotel
Easy & free time for shopping or self activity
Over night stay.</td>
    
  </tr>
<tr>
    <td>Day4 Plan</td>
    <td>Breakfast at hotel
Start back to Dhaka at 1200 hrs
Arrive Dhaka at 2100 hrs
Back to your sweet home & end the trip</td>
    
  </tr>

</table>

</body>
</html>

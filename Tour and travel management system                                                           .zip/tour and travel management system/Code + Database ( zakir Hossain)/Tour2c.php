<!DOCTYPE html>
<html>
<head>
<center><h1><font color="maroon">Tour And Travel management system</font></h1></center>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;       
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>
</head>
<body bgcolor='burlywood'>

<div class="topnav" id="myTopnav">
  <a href="http://localhost/Tour.php" class="active">Home</a>
   <div class="dropdown">
    <button class="dropbtn">Insert
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/Tour1.php">
    Passenger Information</a>
      <a href="http://localhost/Tour2.php">
  Staff Information </a>
      <a href="http://localhost/Tour3.php">
  Vehicle Route</a></a>
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn">View
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/View1.php">
    Passenger Information</a>
      <a href="http://localhost/View2.php">
  Staff Information </a>
      <a href="http://localhost/View3.php">
  Vehicle Route</a></a>
    </div>
  </div> 
  
  
   
  <div class="dropdown">
    <button class="dropbtn">Search
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/Search1c.php">
    Passenger Information</a>
      <a href="http://localhost/Search2c.php">
  Staff Information </a>
      <a href="http://localhost/Search3c.php">
  Vehicle Route</a></a>
    </div>
  </div> 
 
  <a href="http://localhost/Report.php" class="active">Report</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>

<div style="padding-left:16px">




<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<br><br>
<form action="Tour2c.php" method="POST">
<center>
<p>Serial_No:</p>
<input type="text" name="Serial_No" value=" ">
<br>
<p>Staff_ID:</p>
<input type="text" name="Staff_ID" value=" ">
<br>
<p>Staff_Name:</p>
<input type="text" name="Staff_Name" value=" ">
<br>
<p>Staff_Post:</p>
<input type="text" name="Staff_Post" value=" ">
<br>
<input type="submit" value="Save">
<br>
</center>
<center>






<?php
$servername="localhost";
$username="root";
$password="";
$dbname="db_student1";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
	die("coneect failed");
}
else
{
echo "Successfull";
}

$sql="INSERT INTO Staff_Information(Serial_No,Staff_ID,Staff_Name,Staff_Post)VALUES('$_POST[Serial_No]','$_POST[Staff_ID]','$_POST[Staff_Name]','$_POST[Staff_Post]')";
if(mysqli_query($conn, $sql))
{
	echo"new record inserted successfully";
}
else
{
	
	echo"error";
}



mysqli_close($conn);

?>


</body>
</html>
<!DOCTYPE html>
<html>
<head>
<center><h1><font color="maroon">Tour And Travel management system</font></h1></center>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;       
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>
</head>
<body bgcolor='burlywood'>

<div class="topnav" id="myTopnav">
 <a href="http://localhost/Tour.php" class="active">Home</a>
   <div class="dropdown">
    <button class="dropbtn">Insert
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/Tour1.php">
    Passenger Information</a>
      <a href="http://localhost/Tour2.php">
  Staff Information </a>
      <a href="http://localhost/Tour3.php">
  Vehicle Route</a></a>
    </div>
  </div> 
   <div class="dropdown">
    <button class="dropbtn">View
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/view1.php">
    Passenger Information</a>
      <a href="http://localhost/view2.php">
  Staff Information </a>
      <a href="http://localhost/view3.php">
  Vehicle Route</a></a>
    </div>
  </div> 
   <div class="dropdown">
    <button class="dropbtn">Search
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/Search1c.php">
    Passenger Information</a>
      <a href="http://localhost/Search2c.php">
  Staff Information </a>
      <a href="http://localhost/Search3c.php">
  Vehicle Route</a></a>
    </div>
  </div> 
 
  
 
  <a href="http://localhost/Report.php" class="active">Report</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>

<style>

table,th,td {
    border: solid black; text-align: center;
}
footer{
    position: absolute;
    margin: 0% 44%;
    bottom:0;

}
</style>
</head>
<body style="background-image:url('')">
<table style="width:100%">
  <tr style="color:blue">
    <center>
    
    
    <th>Serial_No</th>
    <th>Passenger_ID</th> 
    <th>Passenger_Name</th>
    <th>Passenger_Contact</th>
    
	
  </tr>
<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbName = "db_student1"; 
  $connection = mysqli_connect($servername, $username, $password, $dbName);
if ($connection) {
echo "<br>";
  } else {
die("Connection failed.<br>".mysqli_connect_error());
  }

  $searchKeyword = $_POST["searchKeyword"]; 
  $SQL = "SELECT * FROM `Passenger_Information` WHERE '".$searchKeyword."' IN (Serial_No, Passenger_ID,Passenger_Name, passenger_Contact);";
  $result = mysqli_query($connection, $SQL);
if (!$result || mysqli_num_rows($result) > 0) {
?>

    
    <?php

while($row = mysqli_fetch_assoc($result)) 
   {
echo "<tr>";
echo"<td>".$row['Serial_No']."</td>";
echo"<td>".$row['Passenger_ID']."</td>";
echo"<td>".$row['Passenger_Name']."</td>";
echo"<td>".$row['Passenger_Contact']."</td>";

echo "</tr>";
  }
  } 
else
  {
echo "0 Result";
  }
?>
</center>




</body>
</html>

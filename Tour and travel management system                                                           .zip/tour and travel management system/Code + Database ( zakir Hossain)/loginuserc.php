<?php

// Grab User submitted information
$email = $_POST["email"];
$psw = $_POST["psw"];

// Connect to the database
$con = mysql_connect("localhost","root","");
// Make sure we connected successfully
if(! $con)
{
    die('Connection Failed'.mysql_error());
}

// Select the database to use
mysql_select_db("db_student1",$con);

$result = mysql_query("SELECT email, psw FROM registrationuser WHERE email = $email");

$row = mysql_fetch_array($result);

if($row["email"]==$email && $row["psw"]==$psw)
    echo"You are a validated user.";
else
    echo"Sorry, your credentials are not valid, Please try again.";
?>
<!DOCTYPE html>
<html>



<!DOCTYPE html>


<center><h1><font color="white">Tour And Travel management system</font></h1></center>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<div class="topnav">
  <a class="active" href="galary.php">Home</a>

  <a href="contact.php">Contact</a>
  <a href="about.php">About us</a>
<a href="promotional.php">Promotional meassge</a>
</div>

<div style="padding-left:16px">
 
</div>

<body style="background-color:burlywood;">
<body>
<center>
<h2>Send e-mail to tourbd@gmail.com:</h2>

<form action="mailto:someone@example.com" method="post" enctype="text/plain">
Name:<br>
<input type="text" name="name"><br>
E-mail:<br>
<input type="text" name="mail"><br>
Mobile:<br>
<input type="text" name="comment" size="50"><br><br>
<input type="submit" value="Send">
<input type="reset" value="Reset">
</form>
</center>

</body>
</html>

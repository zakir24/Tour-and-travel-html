<!DOCTYPE html>
<html>



<head>
<body style="background-color:burlywood;">
<center><h1><font color="white">Tour And Travel management system</font></h1></center>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<div class="topnav">
  <a class="active" href="galary.php">Home</a>

  <a href="#contact">Contact</a>
  <a href="#about">About us</a>
<a href="promotional.php">Promotional meassge</a>
</div>

<div style="padding-left:16px">
 
</div>

<head>
<?php
$servername="localhost";
$username="root";
$password="";
$dbname="db_student1";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
	die("coneect failed");
}
else
{
echo "";
}

$sql="INSERT INTO payment(firstname,email,address,city,state,zip,cardname,cardnumber,expmonth,expyear,cvv)VALUES('$_POST[firstname]','$_POST[email]','$_POST[address]','$_POST[city] ','$_POST[state]','$_POST[zip]','$_POST[cardname]','$_POST[cardnumber]','$_POST[expmonth]','$_POST[expyear]','$_POST[cvv]')";
if(mysqli_query($conn, $sql))
{
	 echo" <center><h1><br><br><br><br><br><br><br><br> Thanks for your successfully order. we will contact you within 4 hours and provide you tarvel id <br><h1></center>"; 
}
else
{
	
	echo"error";
}



mysqli_close($conn);

?>




</body>
</html>
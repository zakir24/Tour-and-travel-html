<!DOCTYPE html>
<html>
<head>
<body style="background-color:burlywood;">
<center><h1><font color="white">Tour And Travel management system</font></h1></center>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<div class="topnav">
  <a class="active" href="galary.php">Home</a>

  <a href="#contact">Contact</a>
  <a href="#about">About us</a>
</div>

<div style="padding-left:16px">
 
</div>
<style>

table,th,td {
    border: solid black; text-align: center;
}
footer{
    position: absolute;
    margin: 0% 44%;
    bottom:0;

}
</style>
</head>
<body style="background-image:url('')">
<table style="width:100%">
  <tr style="color:blue">
    <center>
    
    
    <th>Serial_No</th>
  <th>Package_id</th>
    <th>Travel_ID</th> 
    <th>Start_place</th>
    <th>End_Place</th>
    <th>Date</th>
<th>Time</th>
    <th>Coach_Type</th>

    
	
  </tr>
<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbName = "db_student1"; 
  $connection = mysqli_connect($servername, $username, $password, $dbName);
if ($connection) {
echo "<br>";
  } else {
die("Connection failed.<br>".mysqli_connect_error());
  }

  $searchKeyword = $_POST["searchKeyword"]; 
  $SQL = "SELECT * FROM `Vehicle_Route` WHERE '".$searchKeyword."' IN (Serial_No, Package_id, Vehicle_ID,Start_Place,End_Place,Date,Time,Coach_Type);";
  $result = mysqli_query($connection, $SQL);
if (!$result || mysqli_num_rows($result) > 0) {
?>

    
    <?php

while($row = mysqli_fetch_assoc($result)) 
   {
echo "<tr>";
echo"<td>".$row['Serial_No']."</td>";
echo"<td>".$row['Package_id']."</td>";
echo"<td>".$row['Vehicle_ID']."</td>";
echo"<td>".$row['Start_Place']."</td>";
echo"<td>".$row['End_Place']."</td>";
echo"<td>".$row['Date']."</td>";
echo"<td>".$row['Time']."</td>";
echo"<td>".$row['Coach_Type']."</td>";

echo "</tr>";
  }
  } 
else
  {
echo "<center><h1>Not Found</h1></center>";
  }
?>
</center>
<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>


    <div class="page-header">
        <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>.Your package information .</h1>
    </div>
 

  
</body>
</html>
<footer>
<p>
        
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
    </p>
</footer>

 
</body>
</html>

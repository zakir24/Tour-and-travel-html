<!DOCTYPE html>
<html>
<head>
<center><h1><font color="maroon">Tour And Travel management system</font></h1></center>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;       
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>
</head>
<body bgcolor='burlywood'>

<div class="topnav" id="myTopnav">
  <a href="http://localhost/Tour.php" class="active">Home</a>
   <div class="dropdown">
    <button class="dropbtn">Insert
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/Tour1.php">
    Passenger Information</a>
      <a href="http://localhost/Tour2.php">
  Staff Information </a>
      <a href="http://localhost/Tour3.php">
  Vehicle Route</a></a>
    </div>
  </div> 
   <div class="dropdown">
    <button class="dropbtn">View
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/view1.php">
    Passenger Information</a>
      <a href="http://localhost/view2.php">
  Staff Information </a>
      <a href="http://localhost/view3.php">
  Vehicle Route</a></a>
    </div>
  </div> 
   <div class="dropdown">
    <button class="dropbtn">Search
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/search1c.php">
    Passenger Information</a>
      <a href="http://localhost/search2c.php">
  Staff Information </a>
      <a href="http://localhost/search3c.php">
  Vehicle Route</a></a>
    </div>
  </div> 
 
  
 
 <a href="http://localhost/Report.php" class="active">Report</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>

<div style="padding-left:16px">



</div>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "db_student1";
  // Create connection
  $conn = new mysqli($servername, $username, $password,$dbname);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  //echo "Connected successfully\n";

    $sql = "SELECT * FROM Passenger_Information";
    

    $result = $conn->query($sql);
?>

<style>
table,th,td {
    border: solid black; text-align: center;
}
footer{
    position: absolute;
    margin: 0% 44%;
    bottom:0;

}

</style>
</head>
<body style="background-image:url('')">
<table style="width:100%">
  <tr style="color:blue">
    <center>
    <h4>Passenger Information</h4></center>

    <th>Serial_No</th><th>Passenger_ID</th><th>Passenger_Name</th><th>Passenger_Contact</th><th>Edit</th><th>Delete</th><th>Print</th></tr>
<?php
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        // HERE EVERY TABLE DATA WILL CONTAIN DIFFRENT ID TO PRINT
      				echo "<tr><td id='a".$row['Passenger_ID']."'>".$row['Serial_No']."</td><td id='b".$row['Passenger_ID']."'>".$row['Passenger_ID']."</td>";
				echo "<td id='c".$row['Passenger_ID']."'>".$row['Passenger_Name']."</td><td id='d".$row['Passenger_ID']."'>".$row['Passenger_Contact']."</td>";
        

        // EDIT BUTTON CREATION
        echo "<td><form action='' method='GET'><input type='submit' name=".$row['Passenger_ID']." value='Edit'></form></td>";
        // DELETE BUTTON CREATION
        echo "<td><form action='' method='GET'><input type='submit' name='delete".$row['Passenger_ID']."' value='Delete'></form></td>";
        // PDF BUTTON CREATION
        echo "<td><form action='' method='GET'><input type='submit' name='print".$row['Passenger_ID']."' value='Print'></form></td></tr>";

        // UPDATE CODE STARTS FROM HERE

        if(isset($_GET[$row['Passenger_ID']])){
          echo"<form action='' method='POST'><div class='p' Passenger_ID='close'>";// CLASS P IS USED TO DECORATION AND ID CLOSE IS USED TO CLOSE THE POPUP PAGE
                                            echo"<h5>Update Passenger Information</h5>";
                                       echo "Serial_No:</br> <input type='number' name='Serial_No' value=".$row['Serial_No'].">";
					echo "</br></br>";
					echo "Passenger_ID:</br> <input type='text' name='Passenger_ID' value=".$row['Passenger_ID'].">";
					echo "</br></br>";
					echo "Passenger_Name:</br> <input type='text' name='passenger_Name' value=".$row['Passenger_Name'].">";
					echo "</br></br>";
					echo "Passenger_contact:</br> <input type='text' name='Passenger_Contact' value=".$row['Passenger_Contact'].">";
					echo "</br></br>";
					
					
          
          echo"<input type='submit' name = 'submit' value='Update'>";
          
          echo"<input type='submit' name = 'cancle' value='Cancle'>";
          echo "</form>";


          if(isset($_POST['submit'])){
            $Serial_NO = $_POST["Serial_No"];
            $Passenger_ID= $_POST["Passenger_ID"];
            $Passenger_Name= $_POST["Passenger_Name"];
            $Passenger_Contact= $_POST["Passenger_Contact"];
            

            $ssql = "UPDATE Passenger_Information SET Serial_NO='$Serial_NO', Passenger_ID='$Passenger_ID', Passenger_Name='$Passenger_Name', Passenger_Contact='$Passenger_Contact'
            WHERE Passenger_ID=".$row['Passenger_ID']."";
            
            if ($conn->query($ssql) === TRUE) {
            echo "<script type='text/javascript'>alert('Submitted successfully!')</script>";
            } else {
            echo "Upadate Unsucessful". $conn->error;
            }

          }
          if(isset($_POST['cancle'])){
            echo "<script>document.getElementById('close').style.display='none'</script>";
          }
        }

        // DELETE CODE STARTS FORM HERE
        if(isset($_GET['delete'.$row['Passenger_ID']])){
          $delete = "DELETE FROM Passenger_Information WHERE Passenger_ID=".$row['Passenger_ID']."";
          if ($conn->query($delete) === TRUE) {
          echo "<script type='text/javascript'>alert('Deleted successfully!')</script>";
          echo "<meta http-equiv='refresh' content='0'>"; // THIS IS FOR AUTO REFRESH CURRENT PAGE
          } else {
          echo "Delete Unsucessful". $conn->error;
          }
        }

        // PDF STARTS FROM HERE
        if(isset($_GET['print'.$row['Passenger_ID']])){

          echo "<script>
          var mywindow = window.open('', 'PRINT', 'height=400,width=600');
          mywindow.document.write('<html><head><title>' + document.title  + '</title>');
          mywindow.document.write('</head><body >');
          mywindow.document.write('<h1>' + 'Passenger_Information'  + '</h1>');
          mywindow.document.write(document.getElementById('a".$row['Passenger_ID']."').innerHTML);
          mywindow.document.write(' -- ');
          mywindow.document.write(document.getElementById('b".$row['Passenger_ID']."').innerHTML);
          mywindow.document.write(' -- ');
          mywindow.document.write(document.getElementById('c".$row['Passenger_ID']."').innerHTML);
          mywindow.document.write(' -- ');
          mywindow.document.write(document.getElementById('d".$row['Passenger_ID']."').innerHTML);
          mywindow.document.write(' -- ');
      
      
          mywindow.document.write(document.getElementById('e".$row['Passenger_ID']."').innerHTML);
          mywindow.document.write('</body></html>');
          mywindow.document.close(); // necessary for IE >= 10
          mywindow.focus(); // necessary for IE >= 10*/

          mywindow.print();
          mywindow.close();
          history.back(); // IT WILL TAKE YOU BAKE PAGE
          </script>";
        }





      };
    }else{
        echo "No search found!!!";
    }
  $conn->close();
   ?>
<div class="container body-content">

<center



</html>
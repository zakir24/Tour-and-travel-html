<!DOCTYPE html>
<html>
<head>
<center><h1><font color="maroon">Tour And Travel management system</font></h1></center>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;       
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>
</head>
<body bgcolor='burlywood'>

<div class="topnav" id="myTopnav">
  <a href="http://localhost/Tour.php" class="active">Home</a>
   <div class="dropdown">
    <button class="dropbtn">Insert
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/Tour1.php">
    Passenger Information</a>
      <a href="http://localhost/Tour2.php">
  Staff Information </a>
      <a href="http://localhost/Tour3.php">
  Vehicle Route</a></a>
    </div>
  </div> 
   <div class="dropdown">
    <button class="dropbtn">View
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/view1.php">
    Passenger Information</a>
      <a href="http://localhost/view2.php">
  Staff Information </a>
      <a href="http://localhost/view3.php">
  Vehicle Route</a></a>
    </div>
  </div> 
   <div class="dropdown">
    <button class="dropbtn">Search
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/search1c.php">
    Passenger Information</a>
      <a href="http://localhost/search2c.php">
  Staff Information </a>
      <a href="http://localhost/search3c.php">
  Vehicle Route</a></a>
    </div>
  </div> 
 
  
 
 <a href="http://localhost/Report.php" class="active">Report</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>
  
        </div>
		<div id="print">

				<div style="margin-left:250px;margin-top:60px;margin-right:190px;">
			<?php


$conn = mysqli_Connect('localhost','root','','db_student1');
$sql="SELECT Passenger_Information.Serial_No,Passenger_Information.Passenger_ID,Passenger_Information.Passenger_Name,Passenger_Information.Passenger_Contact,Staff_Information.Staff_ID,Vehicle_Route.Vehicle_ID,Vehicle_Route.Start_Place,Vehicle_Route.End_Place,Vehicle_Route.Date,Vehicle_Route.Time,Vehicle_Route.Coach_Type
  FROM Passenger_Information
  LEFT OUTER JOIN Staff_Information ON Passenger_Information.Serial_No=Staff_Information.Serial_No
  LEFT OUTER JOIN  Vehicle_Route ON Staff_Information.Serial_No = Vehicle_Route.Serial_No";



$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0)
{

while ($accused=mysqli_fetch_assoc($result)) 
{
	echo"<div style='position:relative; margin-top:80px;margin-bottom:0px;''>
		


			<center><h3>Tour And Travel Management System</h3></center>
			<center><h4> Uttara Model Town, Uttara,Dhaka-1230</h4></center>
			<center><h4>Contact Number: 01771886857</h4></center>
		</div>";
		echo"<table style='margin-left:0px' border='1'>
  <tr style='color:black'>
 <th>Serial_No</th>
	<th>Passenger_ID</th>
	<th>Passenger_Name</th>
	<th>Passenger_Contact</th>
     <th>Staff_ID</th>
   <th>Vehicle_ID</th>
    <th>Start_Place</th>
	<th>End_Place</th>
	<th>Date</th>
	<th>Time</th>
        <th>Coach_Type</th>
  </tr>";
         echo "<p style='text-align:left;'>Serial_No :".$accused['Serial_No']."</p>";
	echo "<p style='text-align:left;'>Passenger_ID :".$accused['Passenger_ID']."</p>";
     
     
	
	echo "<tr>";
     echo"<td>".$accused['Serial_No']."</td>";
	echo"<td>".$accused['Passenger_ID']."</td>";
	echo"<td>".$accused['Passenger_Name']."</td>";
	echo"<td>".$accused['Passenger_Contact']."</td>";
	echo"<td>".$accused['Staff_ID']."</td>";
        echo"<td>".$accused['Vehicle_ID']."</td>";
	echo"<td>".$accused['Start_Place']."</td>";
        echo"<td>".$accused['End_Place']."</td>";
	echo"<td>".$accused['Date']."</td>";
	echo"<td>".$accused['Time']."</td>";
       echo"<td>".$accused['Coach_Type']."</td>";
	echo "</tr>";
	echo "</table>";
	

}
}
else
{
	echo "Conn failed";
}
?> 
</div>
</div>
<p ><center><a style="background-color:white;" href="javascript:void(0);" onclick="printPage();">PDF</a> </center></p>
 
 </center>


</body>
    </div>
</div>
</body>
<script type="text/javascript">
 function printPage(){
			var prtContent = document.getElementById("print");
			var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0,border=1');
			WinPrint.document.write(prtContent.innerHTML);
			WinPrint.document.close();
			WinPrint.focus();
			WinPrint.print();
			WinPrint.close();
    };
	 </script>

</html>
<!DOCTYPE html>
<html>
<head>
<?php
$servername="localhost";
$username="root";
$password="";
$dbname="db_student1";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
	die("coneect failed");
}
else
{
echo "Successfull";
}

$sql="INSERT INTO registrationuser(name,email,mobile,psw,pswrepeat,address)VALUES('$_POST[name]','$_POST[email]','$_POST[mobile]','$_POST[psw] ','$_POST[pswrepeat]','$_POST[address]')";
if(mysqli_query($conn, $sql))
{
	echo"new record inserted successfully";
}
else
{
	
	echo"error";
}



mysqli_close($conn);

?>




</body>
</html>
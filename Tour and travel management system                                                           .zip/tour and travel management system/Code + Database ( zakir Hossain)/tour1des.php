
<!DOCTYPE html>

<html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<div class="topnav">
  <a class="active" href="galary.php">Home</a>
  <a href="login.php">Login</a>
<a href="register.php">Signup</a>
<a href="promotional.php">Promotional meassge</a>
  <a href="contact.php">Contact</a>
  <a href="about.php">About us</a>

</div>

<div style="padding-left:16px">
 
</div>

<div style="padding-left:16px">


<body bgcolor='burlywood'>

<style>
img {
  float: left;
}
</style>

<body>



<p><img src="tour1i.jpg" alt="Pineapple" style="width:670px;height:370px;margin-left:5px;margin-right:15px;">

 
<b>
 <font color = "green">Price:</font>	<font color = "red">7,500<br><br></font>
 <font color = "green">ID:</font>	<font color = "red">15534 <br><br></font>
 <font color = "green">Item:	</font><font color = "red">Tour Package<br><br></font>
 <font color = "green">Status:	</font><font color = "red">Out of Stock<br><br></font>
 <font color = "green">Updated:</font><font color = "red">3 months ago</font>




</b>
</p>




<head>
      <title>Title of the document</title>
      <style>
         .button {
         background-color: green;
         border: none;
         color: white;
         padding: 20px 34px;
         text-align: center;
         text-decoration: none;
         display: inline-block;
         font-size: 20px;
         margin: 4px 2px;
         cursor: pointer;
         }
      </style>
   </head>
   <body>
      <a href="logindes.php" class="button">Book now</a>
   </body>



<br><br>


<h4>Sundarban tour package cruise for 3 days 2 nights. Travel Route : Khulna-Sundarban-Koromjal-Kotka-Harbaria-Khulna. This Sundarban tourism package includes food menu for 3 days including breakfast, lunch & dinner. Tourists of this Sundarban travel package will depart from Khulna. Experience a Bangladesh domestic holiday vacation trip package with us. The quoted price of the cruise package is per person. Snacks two times a day - biscuits / cakes / fruits, tea/coffee.</h4>

<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<table id="customers">
  
  <tr>
    <td>Duration</td>
    <td>3 Days, 2 Nights</td>
   
  </tr>
  <tr>
    <td>Departure</td>
    <td>Khulna</td>
    
  </tr>
  <tr>
    <td>Destination</td>
    <td>Sundarban, Koromjal, Kotka, Harbaria</td>
    
  </tr>
  <tr>
    <td>Transport</td>
    <td>Ship</td>
  
  </tr>
  <tr>
    <td>Accommodation</td>
    <td>Cabin, Ship</td>
    
  </tr>
  <tr>
    <td>Breakfast</td>
    <td>1. Toast, Butter, Egg-Omlet / Fry, Jam, Sundaban's Honey, Seasonal Fruit, Tea and Coffee 2. Chapati, Omlet, Mixed Vegetable, Sundarban's Honey, Fresh Fruit, Tea and Coffee</td>
    
  </tr>
  <tr>
    <td>Lunch</td>
    <td>1. Plain Rice, Mixed Vegetable, Thick Dal, Fish Fry, Salad, Dessert, Tea and Coffee 2. Plain Polau, Fried Vegetable, Chicken Curry, Salad, Dessert, Tea and Coffee 3. Khichuri, Potato Chop, Fried Vegetable, Mutton Curry, Salad, Dessert, Tea and Coffee</td>
    
  </tr>
  <tr>
    <td>Dinner</td>
    <td>1. Plain Rice, Vegetable Chop, Thick Dal, Fish or Chicken Curry, Mixed Vegetable, Salad, Dessert, Tea & Coffee 2. Fried Rice, Boiled Vegetable, Chicken Curry, Salad, Dessert, Tea & Coffee 3. Fried Rice, Mixed Vegetable, Fish Curry, Salad, Tea & Coffee, Dessert / Plain Rice, Mixed Vegetable, Chicken Curry, Fish Curry, Thick Dal, Cold Drinks or Chicken Fried Rice, Chicken Fry, French Fry, Vegetables</td>
   
  </tr>
  <tr>
    <td>Sight Seeing</td>
    <td>Yes</td>
   
  </tr>
  <tr>
    <td>Guide Service</td>
    <td>Yes</td>
    
  </tr>
<tr>
    <td>Day1 Plan</td>
    <td>Will start for Sundarbans early in the morning from Khulna Rupsha ghat. Reach Kachikhali before evening and scatter about the forest for some time. In kochikhali we'll observe the natural beauty of the Mangrove forest. In the first day, we'll have night halt on boat at Kochikhali. In 2nd day early in the morning, we can cruise the mangrove channel if you like, and come back on boat.</td>
    
  </tr>

<tr>
    <td>Day2 Plan</td>
    <td>After breakfast in the morning, our vessel will move for Kotka tourist spot around the Kotka Sea Beach and the wild forest. In Kotka, we can take bath in Katka Sea-Beach. And after lunch, we will enjoy the office side of the largest mangrove forest and enjoy the sunset. Then we'll come back and we stay night on boat at Kotka</td>
    
  </tr>
<tr>
    <td>Day3 Plan</td>
    <td>Will make our return journey to Khulna at early in the morning. In the last day, if we can afford time, will visit Mongla local village/ Koromjol wildlife centre/ herbaria mangrove trail and attend traditional cultural pursuits of the local villagers</td>
    
  </tr>
</table>

</body>
</html>

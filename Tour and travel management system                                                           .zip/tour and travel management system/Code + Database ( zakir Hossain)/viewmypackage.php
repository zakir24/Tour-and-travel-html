<!DOCTYPE html>
<html>

<head>
<body style="background-color:burlywood;">
<center><h1><font color="white">Tour And Travel management system</font></h1></center>








<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<div class="topnav">
  <a class="active" href="galary.php">Home</a>
<a href="viewmypackage.php">My Account</a>


  <a href="contact.php">Contact</a>
  <a href="about.php">About us</a>
</div>

<div style="padding-left:16px">
 
</div>

		<style>
footer{
    position: absolute;
    margin: 0% 44%;
    bottom: 0;
}
</style>

<center>
 
    <h3><h1>Travel information</h1></h3>

<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
    <div class="page-header">
        <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b> </h1>
    </div>

</body>
</html>



<h4><font color="green">For your journey information write the travel id in this search box . that we provided in your meassage</font> </h4>

<form  method="POST" action="viewmypackagec.php">
	<p>Search:</p>
	<input type="text" name="searchKeyword" value="">
	<br>
	<input type="submit"  value="submit">
</form>
<br>
 <p>
          <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
    </p>


<br><br><br><br><br><br><br><br><br><br>


</body>
</html>

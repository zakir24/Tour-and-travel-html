<!DOCTYPE
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Jotorres Login Form</title>
</head>
<body>
    <form method="post" action="loginuserc.php" >
        <table border="1" >
            <tr>
                <td><label for="email">email</label></td>
                <td><input type="text" 

                  name="email" id="email"></td>
            </tr>
            <tr>
                <td><label for="psw">psw</label></td>
                <td><input name="psw" 

                  type="password" id="psw"></input></td>
            </tr>
            <tr>
                <td><input type="submit" value="Submit"/>
                <td><input type="reset" value="Reset"/>
            </tr>
        </table>
    </form>
</body>
</html>
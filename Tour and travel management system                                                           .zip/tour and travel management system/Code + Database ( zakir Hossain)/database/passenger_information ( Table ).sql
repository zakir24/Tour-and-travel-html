-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2020 at 12:00 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_student1`
--

-- --------------------------------------------------------

--
-- Table structure for table `passenger_information`
--

CREATE TABLE `passenger_information` (
  `Serial_No` int(20) NOT NULL,
  `Passenger_ID` int(30) NOT NULL,
  `Passenger_Name` varchar(30) NOT NULL,
  `Passenger_Contact` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passenger_information`
--

INSERT INTO `passenger_information` (`Serial_No`, `Passenger_ID`, `Passenger_Name`, `Passenger_Contact`) VALUES
(2, 45, ' demo', ' 376578'),
(4, 112, ' zak', ' 093983'),
(1, 1710, ' demo', ' 376578'),
(14, 2343, ' Back', ' 024346364536');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `passenger_information`
--
ALTER TABLE `passenger_information`
  ADD PRIMARY KEY (`Passenger_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2020 at 12:00 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_student1`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `firstname` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `address` varchar(60) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `zip` int(20) NOT NULL,
  `cardname` varchar(25) NOT NULL,
  `cardnumber` int(20) NOT NULL,
  `expmonth` varchar(20) NOT NULL,
  `expyear` int(20) NOT NULL,
  `cvv` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`firstname`, `email`, `address`, `city`, `state`, `zip`, `cardname`, `cardnumber`, `expmonth`, `expyear`, `cvv`) VALUES
('rgwqwffewj', 'wefjwer', '4wefwer', 'wegghwe ', 'evgg', 0, '', 0, '0', 0, 0),
('rgwqwffewj', 'wefjwer', '4wefwer', 'wegghwe ', 'evgg', 10001, '', 0, '0', 0, 0),
('Zakir', 'zakir.pranto@gmail.c', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, '', 0, '0', 0, 0),
('Zakir', 'zakir.pranto@gmail.c', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, '', 0, '0', 2020, 456),
('Zakir', 'zakir.pranto@gmail.c', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, '', 0, 'september', 2020, 456),
('Zakir', 'zakir.pranto@gmail.c', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, '', 0, 'september', 2020, 456),
('Zakir', 'zakir.pranto@gmail.c', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, 'john more done', 1771886857, 'september', 2020, 456),
('Zakir', 'zakir.pranto@gmail.com', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, 'john more done', 1771886857, 'september', 2020, 456),
('Zakir', 'zakir.pranto@gmail.com', 'Chandipur,Sonka,Sherpur,Bogra', 'Sherpur ', 'Bogra', 5800, 'john more done', 1771886857, 'september', 2020, 456),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('Md. Zakir Hossain', 'zakir.pranto@gmail.com', 'Chandipur,Sonka,Sherpur,Bogra', 'Sherpur ', 'Bogra', 5800, '01771886857', 5675697, 'september', 2024, 0),
('Md. Zakir Hossain', 'zakir.pranto@gmail.com', 'Chandipur,Sonka,Sherpur,Bogra', 'Sherpur ', 'Bogra', 5800, '01771886857', 5675697, 'september', 2024, 588),
('Md. Zakir Hossain', 'zakir.pranto@gmail.com', 'Chandipur,Sonka,Sherpur,Bogra', 'Sherpur ', 'Bogra', 5800, '01771886857', 34237642, 'september', 2020, 4556),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('jack', 'john@gmail.com', 'dhaka', 'dhaka ', 'dhaka', 1009, 'Bkash', 0, '', 0, 0),
('jack', 'ec@dbcbd.com', 'qed', 'qed ', 'qedje', 15534, 'Bkash', 0, '', 0, 0),
('jack', 'ec@dbcbd.com', 'qed', 'qed ', 'qedje', 15534, '0170000000', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

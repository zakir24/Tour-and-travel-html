-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2020 at 11:59 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_student1`
--

-- --------------------------------------------------------

--
-- Table structure for table `passenger_information`
--

CREATE TABLE `passenger_information` (
  `Serial_No` int(20) NOT NULL,
  `Passenger_ID` int(30) NOT NULL,
  `Passenger_Name` varchar(30) NOT NULL,
  `Passenger_Contact` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passenger_information`
--

INSERT INTO `passenger_information` (`Serial_No`, `Passenger_ID`, `Passenger_Name`, `Passenger_Contact`) VALUES
(2, 45, ' demo', ' 376578'),
(4, 112, ' zak', ' 093983'),
(1, 1710, ' demo', ' 376578'),
(14, 2343, ' Back', ' 024346364536');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `firstname` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `address` varchar(60) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `zip` int(20) NOT NULL,
  `cardname` varchar(25) NOT NULL,
  `cardnumber` int(20) NOT NULL,
  `expmonth` varchar(20) NOT NULL,
  `expyear` int(20) NOT NULL,
  `cvv` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`firstname`, `email`, `address`, `city`, `state`, `zip`, `cardname`, `cardnumber`, `expmonth`, `expyear`, `cvv`) VALUES
('rgwqwffewj', 'wefjwer', '4wefwer', 'wegghwe ', 'evgg', 0, '', 0, '0', 0, 0),
('rgwqwffewj', 'wefjwer', '4wefwer', 'wegghwe ', 'evgg', 10001, '', 0, '0', 0, 0),
('Zakir', 'zakir.pranto@gmail.c', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, '', 0, '0', 0, 0),
('Zakir', 'zakir.pranto@gmail.c', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, '', 0, '0', 2020, 456),
('Zakir', 'zakir.pranto@gmail.c', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, '', 0, 'september', 2020, 456),
('Zakir', 'zakir.pranto@gmail.c', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, '', 0, 'september', 2020, 456),
('Zakir', 'zakir.pranto@gmail.c', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, 'john more done', 1771886857, 'september', 2020, 456),
('Zakir', 'zakir.pranto@gmail.com', 'Chandipur,Sonka,Sher', 'Sherpur ', 'Bogra', 5800, 'john more done', 1771886857, 'september', 2020, 456),
('Zakir', 'zakir.pranto@gmail.com', 'Chandipur,Sonka,Sherpur,Bogra', 'Sherpur ', 'Bogra', 5800, 'john more done', 1771886857, 'september', 2020, 456),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('Md. Zakir Hossain', 'zakir.pranto@gmail.com', 'Chandipur,Sonka,Sherpur,Bogra', 'Sherpur ', 'Bogra', 5800, '01771886857', 5675697, 'september', 2024, 0),
('Md. Zakir Hossain', 'zakir.pranto@gmail.com', 'Chandipur,Sonka,Sherpur,Bogra', 'Sherpur ', 'Bogra', 5800, '01771886857', 5675697, 'september', 2024, 588),
('Md. Zakir Hossain', 'zakir.pranto@gmail.com', 'Chandipur,Sonka,Sherpur,Bogra', 'Sherpur ', 'Bogra', 5800, '01771886857', 34237642, 'september', 2020, 4556),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('jack', 'john@gmail.com', 'dhaka', 'dhaka ', 'dhaka', 1009, 'Bkash', 0, '', 0, 0),
('jack', 'ec@dbcbd.com', 'qed', 'qed ', 'qedje', 15534, 'Bkash', 0, '', 0, 0),
('jack', 'ec@dbcbd.com', 'qed', 'qed ', 'qedje', 15534, '0170000000', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0),
('', '', '', ' ', '', 0, '', 0, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `staff_information`
--

CREATE TABLE `staff_information` (
  `Serial_No` int(20) NOT NULL,
  `Staff_ID` int(30) NOT NULL,
  `Staff_Name` varchar(30) NOT NULL,
  `Staff_Post` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_information`
--

INSERT INTO `staff_information` (`Serial_No`, `Staff_ID`, `Staff_Name`, `Staff_Post`) VALUES
(1, 45, ' dem', ' manager'),
(14, 23443, ' Nack', ' manager');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'zakir22', '$2y$10$ctceRdZWhsYzsNeQkYR.w.TuY9tNO3i2svz6UsPQ6blPoKJat9c7O', '2020-04-03 14:08:50'),
(2, 'jack', '$2y$10$.eTSoXlGS9AZZcFp8g8nTu12WmCgozvPmoHzPy8S/3VSbhU3cqUMq', '2020-04-06 11:00:56'),
(3, 'jh12', '$2y$10$PyOUmcoo2h1TyuEcI2JfKezt1sbGLmXudfm/GQSLHlqpo1OfImqKK', '2020-04-06 11:11:03'),
(4, 'zakir20', '$2y$10$oxEWjH47cIhrREMVr83uAuvCx6Q.MIWGtnrLyAbvB3TNFXZU0KstC', '2020-04-06 22:57:08'),
(5, 'jack20', '$2y$10$IK50Eo0UyetOInCscimTdeBt3xZYJaoFKcPlQXG1KhQRnka44ycuu', '2020-04-06 23:08:56'),
(6, 'jack10', '$2y$10$6OOlie2IXIsKisUJrMHKfeSPVT1lvi3bsL6.cf0vUbbohjA0YjvZS', '2020-04-06 23:10:53'),
(7, 'jack05', '$2y$10$s6wV3mNfRkiz3cxFbd6UE.2kAHz13OolZPO8IPZejTqGRmRb2dLOe', '2020-04-06 23:13:37'),
(8, 'jack01', '$2y$10$C82A9iz7BoAW0wGltvwq8.H/pA.y3qz9XOSTWTdxT0wRp1Oz0Czw.', '2020-04-06 23:18:23'),
(9, 'jack02', '$2y$10$bqA2IoaFLtM4S3kB5E/UB.7WWKE70nnKD3lvqy6.uhLfjm26C7pCK', '2020-04-06 23:24:27'),
(10, 'zakir10', '$2y$10$MThx2ex6MC6GdjKhbsOXPuGdwzgeSoISsskRSea.ALk8q1g/VKNpa', '2020-04-23 14:11:38'),
(11, 'zakir19', '$2y$10$9QgUgtvU31JVqMRjtw4X3.Rccz8VeqpZK1i28SmAwwn8UmpE5gFWO', '2020-04-23 14:12:25');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_route`
--

CREATE TABLE `vehicle_route` (
  `Serial_No` int(20) NOT NULL,
  `Package_id` int(20) NOT NULL,
  `Vehicle_ID` int(30) NOT NULL,
  `Start_Place` varchar(30) NOT NULL,
  `End_Place` varchar(30) NOT NULL,
  `Date` varchar(20) NOT NULL,
  `Time` varchar(20) NOT NULL,
  `Coach_Type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle_route`
--

INSERT INTO `vehicle_route` (`Serial_No`, `Package_id`, `Vehicle_ID`, `Start_Place`, `End_Place`, `Date`, `Time`, `Coach_Type`) VALUES
(123, 0, 124, 'Dhaka', 'Sylhet', '01-01-01', '6', 'Non AC'),
(125, 127, 129, ' Dhaka', ' Sylhet', ' 01-01-01', ' 6 pm', ' AC'),
(14, 2364, 1634136, ' Dhaka', ' Gazipur', ' 01-01-01', ' 6 pm', ' AC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `passenger_information`
--
ALTER TABLE `passenger_information`
  ADD PRIMARY KEY (`Passenger_ID`);

--
-- Indexes for table `staff_information`
--
ALTER TABLE `staff_information`
  ADD PRIMARY KEY (`Staff_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `vehicle_route`
--
ALTER TABLE `vehicle_route`
  ADD PRIMARY KEY (`Vehicle_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
